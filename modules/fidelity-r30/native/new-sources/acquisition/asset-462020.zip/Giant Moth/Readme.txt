Files are provided from the Pl0 game folder. The Pl0 and Pl1 folders (Leon/Claire scenarios) contain identical files, with very few exceptions; Pl1 files are not included unless specifically noted.

An extra texture, EM13A, is included in the Pl0 folder. The Pl0 model EM03A is identical to the Pl1 model EM13A, but the Pl0 folder also contains an extra texture named EM13A which is not identical and has no associated model. This texture appears to be unused.

Files labeled emdui were exported using emdui (emd UI) by IntelOrca.
Files labeled RE2MV were exported using RE2MV (Resident Evil 2 Model Viewer) by Leo2236.
Files labeled tim2view were exported using tim2view by Lab 313.