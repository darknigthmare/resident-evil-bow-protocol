em11 - Sleeveless Collared Shirt, Skirt
em13 - Dress, Pigtails
em19 - Vest, Long Pants
em1d - Police Uniform
em1f - T-Shirt/Tank Top, Shorts

For models em13 and em1f, multiple variants are included, named _0 and _1.

For model em13, the tim2view texture does not include transparency, while the emdui version does. Raw data color conversion is handled differently by emdui versus tim2view, in this case leading to differences in the range of pixels that are interpreted as black 0,0,0.

Files are provided from the emd game folder. The emd08 folder (Carlos player segment) contains identical files.

Files labeled emdui were exported using emdui (emd UI) by IntelOrca.
Files labeled tim2view were exported using tim2view by Lab 313.