em1400 and em1401 both use om1706 as a "bear trap" weapon, and for both variants the om1706 model and textures are identical.

em1400 and em1401 use the same skeleton and share the same animations.